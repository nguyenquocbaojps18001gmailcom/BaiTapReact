import React from "react";

export default function Footer() {
    return (
        <div className="footer" 
        style={{ 
            backgroundColor: 'green', 
            textAlign: 'center', 
            padding: '15px 0', 
            color: 'white' }}>
            Copyright by Mr.Nguyen
        </div>
    );
}