import React from "react";
import Cart from "./card";

export default function Listcard() {
    return (
        <div className="row">
            <Cart />
            <Cart />
            <Cart />
        </div>
    );
}