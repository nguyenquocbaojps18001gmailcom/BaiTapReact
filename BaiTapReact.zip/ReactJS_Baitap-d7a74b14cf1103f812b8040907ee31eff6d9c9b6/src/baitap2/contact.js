import React from "react";

export default function Contact() {
    return (
        <div className="col-sm-4">
            <h1>Contact US</h1>
            <p>CyberSoft</p>
            <p>Su Van Hanh, quận 10, Tp.HCM</p>
            <p>website: cybersoft.edu.vn</p>
        </div>
    );
}