import React, {Component} from "react";
import { render } from "@testing-library/react";

export default class Sidebar extends Component {
    render(){
        return <div className="sidebar">Sidebar</div>
    }
}